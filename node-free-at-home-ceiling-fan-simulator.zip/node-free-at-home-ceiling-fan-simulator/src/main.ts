// This is the main program. This program is called by node or the sysAP-Scripting host

// Import CeilingFan-Class from CeilingFan.ts
import { CeilingFanSimulator } from './CeilingFan'


// Create virtual Ceiling fan. First SerialNo, second friendly name
const Fan = new CeilingFanSimulator("123abcawe987zyx", "Very special switch");