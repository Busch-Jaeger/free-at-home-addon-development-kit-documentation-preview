// Import free@home library and especially CeilingFanChannel
import { FreeAtHome, CeilingFanChannel } from 'free-at-home';


// Create new free@home object
const freeAtHome = new FreeAtHome();


// The virtual CeilingFan is represented by a class
export class CeilingFanSimulator {
    // SerialNo
    protected Serial: string;
    // Friendly Name
    protected Name: string;
    // Ceiling Fan Object
    protected Fan: CeilingFanChannel | undefined = undefined;
    // Value of CeilingFan Speed (0-100%)
    protected FanSpeed: number;

    // Class constructor
    // SerialNo an name are coming from main.ts
    constructor(_Serial: string, _Name: string) {
        this.Name = _Name;
        this.Serial = _Serial;

        // CeilingFan is initialized, so set the Fan Speed to 0
        this.FanSpeed = 0;

        // Send KeepAlive signal each 30s. Otherwise the device will become "unresponsive"
        setInterval(this.keepAlive.bind(this), 30000);

        // Finally call function, which creates the Fan
        this.createDevice();
    }

    // Create Fan Subfuction
    async createDevice() {
        try {
            // Create Fan Object with SerialNo an Name
            this.Fan = await freeAtHome.createCeilingFan(this.Serial, this.Name);

            // Register Handler for different Fan "events"
            // Handler for turning on/off
            this.Fan.on("isOnChanged", this.onChanged.bind(this));

            // Handler for absolute change in fan speed (absolut value between 0 and 100% )
            this.Fan.on("absoluteFanSpeedChanged", this.absoluteFanSpeedChanged.bind(this));

            // Handler for relative change (+ / - 10 % for example)
            this.Fan.on("relativeFanSpeedChanged", this.relativeFanSpeedChanged.bind(this));


        }
        catch (err) {
            console.error(err);
        }
    }

    // Function for change in Powerstate (on/off)
    onChanged(value: any) {
        // Check if Fan is defined (created)
        if (this.Fan === undefined)
            return;

        // Log to console
        console.log("Change in PowerState. ON  = true, OFF = false");
        console.log(value);
        this.Fan.setOnOff(value);

        // If Fan is turned off (false), set fan speed to 0%
        if (value === false) {
            this.Fan.setAbsoluteFanSpeed("0");
        }
        // If its turned on, set fan speed to last fan speed
        else {
            this.Fan.setAbsoluteFanSpeed(this.FanSpeed.toString());
        }

    }

    // Function for change of absolute fan speed (0-100 %)
    absoluteFanSpeedChanged(value: any) {
        // Check if Fan is defined (created)
        if (this.Fan === undefined)
            return;
        // Log fan speed value to console    
        console.log("Absolut fan speed: ");
        console.log(value);
        // Parse fan speed as integer
        this.FanSpeed = parseInt(value);
        // Set fan speed to requested value
        this.Fan.setAbsoluteFanSpeed(value);

        // Turn on fan, if it was powered off 
        console.log("Power on");
        this.Fan.setOnOff(true);

    }

    // Function for relative change of fan speed (+/- 10 %)
    relativeFanSpeedChanged(value: any) {
         // Check if Fan is defined (created)
        if (this.Fan === undefined)
            return;
        // Log fan speed change to console    
        console.log("Relative fan speed: ");
        console.log(value);

        // Parse fan speed as integer
        let relativeSpeed = parseInt(value);

        // Increase or decrease fan speed
        this.FanSpeed = this.FanSpeed + relativeSpeed;

         // Set fan speed to requested value
         this.Fan.setAbsoluteFanSpeed(value);

         // Turn on fan, if it was powered off 
        console.log("Power on");
        this.Fan.setOnOff(true);

    }

    // Function for keeping device alive ("responsive")
    keepAlive() {
        // Check if Fan is defined (created)
        if (this.Fan === undefined)
            return;

        // Log to console    
        console.log("KeepAlive");

        // Send KeepAlive Command
        this.Fan.triggerKeepAlive().catch((err) => {
            console.error(err);
        });
    }
}


